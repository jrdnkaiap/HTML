<!DOCTYPE html>
<html>
<body>
starting <br><br>
<!-- Connecting to database -->
 <?php
//Initialise Variables
 $servername = "localhost";
 $username = "compsciDev";
 $password = "ISCTStudentDev123!@#";
 $dbname = "CompSciStudent";

 //turn error handling on
ini_set('display_errors', 'On');
error_reporting(E_ALL);
echo "Up and running at ";
echo date("d-m-y  h:i:s");

//establish a connection
$mysqli = new mysqli($servername,$username,$password,$dbname);
//$sqlcommand = "SELECT id, firstname, lastname FROM MyGuests";
//$result = mysqli_query($conn, $sql);
?>
